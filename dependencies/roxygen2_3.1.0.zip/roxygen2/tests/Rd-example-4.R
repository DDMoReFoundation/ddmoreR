x %*% y # \x
