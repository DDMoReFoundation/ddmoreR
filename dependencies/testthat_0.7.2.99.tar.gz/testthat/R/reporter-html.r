#' @include reporter.r
NULL

#'TODO
#' test <- package("testthat", reporter = HtmlReporter$new(file =file.path(getwd(), "test.html")))
#' @export
#' @exportClass HtmlReporter
#' @aliases HtmlReporter-class
#' @examples
#' if (require("XML")) {
#' test_package("testthat", reporter = HtmlReporter$new(file = "testjunit.html"))
#' }
#' @keywords debugging
HtmlReporter <- setRefClass("HtmlReporter", contains = "Reporter",
  fields = list(
    "file" = "character",
    "results" = "list",
    "timer" = "ANY"),

  methods = list(

    initialize = function(file = "", ...) {
      if (!require("XML", quietly = TRUE)) {
        stop("Please install the XML package", call. = FALSE)
      }
      callSuper(...)
      file <<- file
      results <<- list()
    },

    start_reporter = function() {
      callSuper()
      results <<- list()
      timer <<- proc.time()
      context <<- "(ungrouped)"
    },

    start_context = function(desc) {
      callSuper(desc)
      cat(desc, ": ", file = stderr())
    },

    end_context = function() {
      callSuper()
      cat("\n", file = stderr())
    },

    add_result = function(result) {
      if (result$passed) {
        cat(colourise(".", fg = "light green"), file = stderr())
      } else {
        failed <<- TRUE
        if (result$error) {
          cat(colourise("F", fg = "red"), file = stderr())
        } else {
          cat(colourise("E", fg = "red"), file = stderr())
        }
      }
      result$time <- round((proc.time() - timer)[["elapsed"]], 2)
      timer <<- proc.time()
      result$test <- if (is.null(test) || test == "") "(unnamed)" else test
      result$call <- if (is.null(result$call)) "(unexpected)" else result$call
      results[[context]] <<- append(results[[context]], list(result))
    },

    end_reporter = function() {
      cat("\n", file = stderr())
    header <- "<head><meta content=\"text/html; charset=UTF-8\" http-equiv=\"Content-Type\"></meta></head>" 
    title1 <- paste0("<h1>TEST PROTOCOL: ", 
                    format(Sys.time(), format = "%a %b %d %H:%M:%S"), 
                    "</h1>")
    title2 <- paste0("<h2> Platform</h2>")
    env <- paste0("<p> Platform: ", version$system, "</p>", 
                  "<p> ", version$version.string, "</p>", 
                  "<p> Host: ",
                  ifelse(version$os=="mingw32", Sys.getenv("COMPUTERNAME"), Sys.getenv("HOSTNAME")), 
                 "</p>"
                 )
    title3 <- paste0("<h3> Summary </h3>")
     summary1 <-  sapply(results, function(context){
              resultSummary <- c(length(context),
                                 rowSums(sapply(context, function(test){
                                            return(c(test$passed, test$error, test$time))
                                               }
                                                )
                                        )
                                 )
        })
      summary1 <- t(summary1);summary1[,2] <- summary1[,1]-summary1[,2]-summary1[,3];
      summary1 <- data.frame(summary1); names(summary1) <- c("Tests", "Errors", "Failures", "time")

      summary2 <- colSums(summary1)
      summary2 <- paste0("<p>Number of tests:    ", summary2[1], "</p>\n",
                         "<p>Number of errors:   ", summary2[2], "</p>\n", 
                         "<p>Number of failures: ", summary2[3], "</p>\n",
                         "<p>Time total:         ", summary2[4], "</p>\n"
                         )
    
      dataFrameToTable <- function(table){
         htmlTable <- apply(X = cbind(row.names(table),table), MARGIN = 1, 
                          FUN = function(Ligne){
                                  paste0("<td>", paste0(Ligne, collapse = "</td><td>"),"</td>")
                             })
         htmlHeader <- paste0("<th>",paste0(c("", names(table)), collapse = "</th><th>"),"</th>")
         htmlTable <- paste0("<table><tr>", paste0(c(htmlHeader,htmlTable), collapse= "</tr><tr>"), "</tr></table>")
         return(htmlTable)
        }
      title4 <- paste0("<h2> Details</h2>")

      suites <- lapply(results, function(context) {
        testsuite <-  sapply(context,function(XX){
                                 data.frame(t(unlist(XX)))} )
        testsuite <- do.call("rbind", context)
        dataFrameToTable(testsuite)
       })
       suites <- paste0("<h3>", names(results),"</h3>" , suites, collapse = "\n")
                       
      htmlString <- paste0("<html>",header, title1,title2, env,"<hr></hr>" ,
                           title3, summary2 ,"<hr></hr>", dataFrameToTable(summary1),
                           title4, suites ,  "</html>")
      cat(htmlString,
          file = file )
     }
  )
)
