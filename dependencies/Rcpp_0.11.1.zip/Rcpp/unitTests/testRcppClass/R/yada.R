loadModule("yada", c("bar", baz = "bla", baz1 = "bla1", "foo"))
