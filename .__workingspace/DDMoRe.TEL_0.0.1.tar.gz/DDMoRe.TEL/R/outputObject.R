outputObject.getJobID <- function(x, ..) {
  
  x$requestID
  
}