#include "Rcurl.h"


/* Not thread-safe, but okay for now. */
static char RCurlErrorBuffer[1000] = "<not set>";

#define R_CURL_CHECK_ERROR(status, handle) 	if(status != CURLE_OK) getCurlError(handle, 1);


/* Callback routines that can be used to call R functions as handlers.  */
size_t R_curl_write_data(void *buffer, size_t size, size_t nmemb, SEXP fun);
int R_curl_getpasswd(SEXP fun, char *prompt, char* buffer, int  buflen  );
int R_curl_debug_callback (CURL *curl, curl_infotype type, char  *msg,  size_t len,  SEXP fun);

void * getCurlPointerForData(SEXP el, CURLoption option, Rboolean isProtected, CURL *handle);
SEXP makeCURLcodeRObject(CURLcode val);
CURL *getCURLPointerRObject(SEXP obj);
SEXP makeCURLPointerRObject(CURL *obj);
char *getCurlError(CURL *h, int throw);
SEXP RCreateNamesVec(const char * const *vals,  int n);

void addFormElement(SEXP el, SEXP name, struct curl_httppost **post, struct curl_httppost **last, int which);
void buildForm(SEXP params, struct curl_httppost **post, struct curl_httppost **last);

SEXP getRStringsFromNullArray(const char **d);
SEXP RCurlVersionInfoToR(curl_version_info_data *d);

struct curl_slist* Rcurl_set_header(CURL *obj, SEXP headers, Rboolean isProtected);

SEXP getCurlInfoElement(CURL *obj, CURLINFO id);



SEXP
R_curl_easy_init(void)
{
	CURL *obj;
	obj = curl_easy_init();
	if(obj) {
/*XX Debugging options */
 	    curl_easy_setopt(obj, CURLOPT_HTTPAUTH, CURLAUTH_ANY); /* or CURLAUTH_BASIC*/

	    if(curl_easy_setopt(obj, CURLOPT_ERRORBUFFER, RCurlErrorBuffer))
   	       getCurlError(obj, 1);

	}
	return(makeCURLPointerRObject(obj));
}



SEXP
R_curl_easy_duphandle(SEXP handle)
{
	CURL *obj;
	obj = getCURLPointerRObject(handle);

	obj = curl_easy_duphandle(obj);

	return(makeCURLPointerRObject(obj));
}


SEXP
R_curl_easy_perform(SEXP handle, SEXP opts, SEXP isProtected)
{
	CURL *obj;
	CURLcode status;

	if(GET_LENGTH(opts)) {
  	    R_curl_easy_setopt(handle, VECTOR_ELT(opts, 1), VECTOR_ELT(opts, 0), isProtected);
	}

	obj = getCURLPointerRObject(handle);
	status =  curl_easy_perform(obj);

	R_CURL_CHECK_ERROR(status, obj);


	return(makeCURLcodeRObject(status));
}

SEXP
R_curl_global_cleanup()
{
	curl_global_cleanup();
	return(R_NilValue);
}

SEXP
R_curl_global_init(SEXP flag)
{
	CURLcode status;
	status = curl_global_init(INTEGER(flag)[0]);
	return(makeCURLcodeRObject(status));
}

SEXP
R_curl_easy_setopt(SEXP handle, SEXP values, SEXP opts, SEXP isProtected)
{
	CURL *obj;
	CURLcode status = 0;
	CURLoption opt;

	int i, n;
	void *val;
	SEXP el;

        /* get the CURL * handler */
	obj = getCURLPointerRObject(handle);

        /* Find out how many options we are setting. */
	n = GET_LENGTH(values);

	/* Loop over all the options we are setting. */
	for(i = 0; i < n; i++) {
		opt = INTEGER(opts)[i];
		el = VECTOR_ELT(values, i);
  		   /* Turn the R value into something we can use in libcurl. */
		val = getCurlPointerForData(el, opt, LOGICAL(isProtected)[0], obj);

                if(opt == CURLOPT_WRITEFUNCTION && TYPEOF(el) == CLOSXP) {
			status =  curl_easy_setopt(obj, CURLOPT_WRITEFUNCTION, &R_curl_write_data);
			status =  curl_easy_setopt(obj, CURLOPT_FILE, val);
		} else  if(opt == CURLOPT_DEBUGFUNCTION && TYPEOF(el) == CLOSXP) {
			status =  curl_easy_setopt(obj, opt, &R_curl_debug_callback);
			status =  curl_easy_setopt(obj, CURLOPT_DEBUGDATA, val);
		} else  if(opt == CURLOPT_HEADERFUNCTION && TYPEOF(el) == CLOSXP) {
			status =  curl_easy_setopt(obj, opt, &R_curl_write_data);
			status =  curl_easy_setopt(obj, CURLOPT_WRITEHEADER, val);
		} else {
			status = curl_easy_setopt(obj, opt, val);
		}

		if(status) {
			PROBLEM "Error setting the option for # %d (status = %d) (enum = %d) (value = %p): %s %s", 
                                    i+1, status, opt, val, curl_easy_strerror(status), getCurlError(obj, 0)
			WARN;
		}

	}

	return(makeCURLcodeRObject(status));
}



SEXP
R_post_form(SEXP handle, SEXP opts, SEXP params, SEXP isProtected)
{
	CURLcode status;
	CURL *obj;
        struct curl_httppost* post = NULL;
        struct curl_httppost* last = NULL;


        /* get the CURL * handler */
	obj = getCURLPointerRObject(handle);

	buildForm(params, &post, &last);
         /* Arrange to have this struct curl_httppost object cleaned. */
	RCurl_addMemoryAllocation(CURLOPT_HTTPPOST, post, obj);

	if(GET_LENGTH(opts)) {
  	    R_curl_easy_setopt(handle, VECTOR_ELT(opts, 1), VECTOR_ELT(opts, 0), isProtected);
	}

        curl_easy_setopt(obj, CURLOPT_HTTPPOST, post);

	status = curl_easy_perform(obj);


/*      Not supposed to call free here until we do the cleanup on the CURL object.
        We do it with the memory management for the CURL that we have for general
        allocations for that structure.
        Alternatively, we could duplicate the CURL object and then cleanup and free the form.
	curl_formfree(post) but this wouldn't be ideal.
 */

	R_CURL_CHECK_ERROR(status, obj);

	return(makeCURLcodeRObject(status));
}

void
buildForm(SEXP params, struct curl_httppost **post, struct curl_httppost **last)
{
	int i, n;
	SEXP names;

	n = GET_LENGTH(params);
	names = GET_NAMES(params);

	for(i =0; i < n ; i++) {
		addFormElement(VECTOR_ELT(params, i), STRING_ELT(names, i), post, last, i);
	} 
}

void
addFormElement(SEXP el, SEXP name, struct curl_httppost **post, struct curl_httppost **last, int which)
{
    curl_formadd(post, last, 
		 CURLFORM_PTRNAME, CHAR(name),
		 CURLFORM_NAMELENGTH, strlen(CHAR(name)), 
		 CURLFORM_PTRCONTENTS, CHAR(STRING_ELT(el, 0)),
		 CURLFORM_END);
}



/* Use R_curl_version_info instead from R and extract the piece you want. 
   Not currently exported via the registration mechanism.
*/
SEXP
R_curl_version()
{
	return(mkString(curl_version()));
}

SEXP
R_curl_version_info(SEXP flag)
{
	curl_version_info_data *data;
	data = curl_version_info(INTEGER(flag)[0]);
	return(RCurlVersionInfoToR(data));
}


#if 0
SEXP
R_curl_set_header(SEXP handle, SEXP headers, SEXP isProtected)
{
	CURL *obj;
	struct curl_slist *headerList;
	obj = getCURLPointerRObject(handle);
	headerList = Rcurl_set_header(obj, headers, LOGICAL(isProtected)[0]);

/*XXX Do something with the list here. */
	return(R_NilValue);
}
#endif



struct curl_slist*
Rcurl_set_header(CURL *obj, SEXP headers, Rboolean isProtected)
{
	char *val;
	int n, i;
	struct curl_slist *headerList = NULL;

	n = GET_LENGTH(headers);

	for(i = 0; i < n; i++) {
		val = CHAR(STRING_ELT(headers, i));
		if(!val || !val[0]) {
			PROBLEM "No value for HTTP header entry %d, ignoring it", i+i
			WARN;
			continue;
		}
		val = isProtected ? val : strdup(val);
		headerList = curl_slist_append(headerList, val);
		if(!isProtected) {
			RCurl_addMemoryAllocation(CURLOPT_LASTENTRY, val, obj);			
		}
	}

#if 0
	if(obj)
   	   curl_easy_setopt(obj, CURLOPT_HTTPHEADER, headerList);
#endif

	return(headerList);
}


SEXP
R_curl_easy_getinfo(SEXP handle, SEXP which)
{
	CURL *obj;
	int i, n;
	SEXP ans;

	obj = getCURLPointerRObject(handle);

	n = GET_LENGTH(which);
	PROTECT(ans = allocVector(VECSXP, n));
	for(i = 0; i < n; i++) {
	  SET_VECTOR_ELT(ans, i, getCurlInfoElement(obj, INTEGER(which)[i]));
	}
	UNPROTECT(1);
	return(ans);
}


SEXP
R_curl_escape(SEXP vals, SEXP escape)
{
	int i, n;
	SEXP ans = R_NilValue;
	n = GET_LENGTH(vals);
	PROTECT(ans = allocVector(STRSXP, n));
	for(i = 0; i < n ; i++) {
		char *tmp, *ptr;
		ptr = CHAR(STRING_ELT(vals, i));
		if(ptr) {
			tmp = LOGICAL(escape)[0] ? curl_escape(ptr, 0) : curl_unescape(ptr, 0);
			if(tmp) {
				SET_VECTOR_ELT(ans, i, COPY_TO_USER_STRING(tmp));
				curl_free(tmp);
			}
		}
	}
	UNPROTECT(1);
	return(ans);
}


/****************************************************************/


SEXP
getCurlInfoElement(CURL *obj, CURLINFO id)
{
	double d;
	long l;
	char *s;
	SEXP ans = R_NilValue;

	switch( id & CURLINFO_TYPEMASK) {
  	    case CURLINFO_STRING:
		    curl_easy_getinfo(obj, id, &s);
		    if(s)
			ans = mkString(s);
	      break;
  	    case CURLINFO_DOUBLE:
		    curl_easy_getinfo(obj, id, &d);
		    ans = ScalarReal(d);
	      break;
  	    case CURLINFO_LONG:
		    curl_easy_getinfo(obj, id, &l);
		    ans = ScalarReal((double) l);
	      break;
  	    default:
		    PROBLEM "invalid getinfo option identifier"
		    ERROR;
	}

	return(ans);
}


int
R_curl_getpasswd(SEXP fun, char *prompt, char* buffer, int  buflen  )
{
	SEXP e, ans;
	int errorOccurred, status = 0;

	PROTECT(e = allocVector(LANGSXP, 3));
	SETCAR(e, fun);
	SETCAR(CDR(e), mkString(prompt));
	SETCAR(CDR(CDR(e)), ScalarInteger(buflen));

	ans = R_tryEval(e, R_GlobalEnv, &errorOccurred);
	if(GET_LENGTH(ans) > 0 && TYPEOF(ans) == STRSXP) {
	   strncpy(buffer, CHAR(STRING_ELT(ans, 0)), buflen);
	} else
 	    status = 1;

	UNPROTECT(1);

	return(status);
}


char *
getCurlError(CURL *h, int throw)
{
   if(throw) {
	   PROBLEM "%s", RCurlErrorBuffer
	   ERROR;
   }
   return(RCurlErrorBuffer);
}



void *
getCurlPointerForData(SEXP el, CURLoption option, Rboolean isProtected, CURL *curl)
{
	void *ptr = NULL;
	int i, n;

	switch(TYPEOF(el)) {
	    case STRSXP:
		    if(option == CURLOPT_HTTPHEADER) {
                                   /* struct curl_slist */
			 ptr = (void *) Rcurl_set_header(curl, el, isProtected);
			 isProtected = FALSE;
		    } else {
/*XX Memory management */
			    if(GET_LENGTH(el) == 1) {
				    ptr = (isProtected ? CHAR(STRING_ELT(el, 0)) : strdup(CHAR(STRING_ELT(el, 0))));
			    } else {
				    char **els;
				    n = GET_LENGTH(el);
				    ptr = (void *) els = (char **) malloc(sizeof(char *) * n);
				    for(i = 0; i < n; i++) {
					    els[i] = (isProtected ? CHAR(STRING_ELT(el, i)) : strdup(CHAR(STRING_ELT(el, i))));
				    }
			    }
		    }
  	      break;
  	    case CLOSXP:
		    if(!isProtected)
		       R_PreserveObject(el);
		    ptr = (void *) el;
  	      break;

	    case LGLSXP:
		    ptr = (void *) malloc(sizeof(long));
		    *( (long*) ptr) = (long) LOGICAL(el)[0];
	      break;
	    case REALSXP:
		    ptr = (void *) malloc(sizeof(long));
		    *( (long*) ptr) = (long) REAL(el)[0];
	      break;
	    case INTSXP:
		    ptr = (void *) malloc(sizeof(long));
		    *( (long*) ptr) = (long) INTEGER(el)[0];
	      break;
   	    default:
		    PROBLEM "Unhandled case for curl_easy_setopt"
		    ERROR;
  	      break;
	}

	if(!isProtected)
		RCurl_addMemoryAllocation(option, ptr, curl);

	return(ptr);
}


size_t
R_curl_write_data(void *buffer, size_t size, size_t nmemb, SEXP fun)
{
	SEXP str, e;
	int errorOccurred;


	PROTECT(e = allocVector(LANGSXP, 2));
	SETCAR(e, fun);

	PROTECT(str = allocString(size * nmemb + 1));
	memcpy(CHAR(str), buffer, size * nmemb);
	CHAR(str)[size * nmemb] = '\0';
	SETCAR(CDR(e), ScalarString(str));

	R_tryEval(e, R_GlobalEnv, &errorOccurred);

	UNPROTECT(2);
	return(size * nmemb);
}


int
R_curl_debug_callback (CURL *curl, curl_infotype type, char  *msg,  size_t len,  SEXP fun)
{
	SEXP str, e;
	int errorOccurred;

	PROTECT(e = allocVector(LANGSXP, 4));
	SETCAR(e, fun);

	PROTECT(str = allocString(len * sizeof(char) + 1));
	memcpy(CHAR(str), msg, len);
	CHAR(str)[len] = '\0';
	SETCAR(CDR(e), ScalarString(str));

	SETCAR(CDR(CDR(e)), ScalarInteger(type));

	SETCAR(CDR(CDR(CDR(e))), R_MakeExternalPtr((void *) curl, Rf_install("CURLHandle"), R_NilValue));

	R_tryEval(e, R_GlobalEnv, &errorOccurred);

	UNPROTECT(2);
	return(0);
}


SEXP
makeCURLcodeRObject(CURLcode val)
{
	SEXP ans;
	ans = allocVector(INTSXP, 1);
/*XXX Put a name on this to get the symbolic value. */
	INTEGER(ans)[0] = val;
	return(ans);
}

CURL *
getCURLPointerRObject(SEXP obj)
{
	CURL *handle;
	handle = (CURL *) R_ExternalPtrAddr(obj);
	if(!handle) {
		PROBLEM "Stale CURL handle being passed to libcurl"
		ERROR;
	}

	return(handle);
}

void
R_finalizeCurlHandle(SEXP h)
{
   CURL *curl = getCURLPointerRObject(h);
   if(curl) {
/*     fprintf(stderr, "Clearing %p\n", (void *)curl);fflush(stderr); */

     RCurl_releaseMemoryTickets(curl);
     curl_easy_cleanup(curl);
   }
}

SEXP
makeCURLPointerRObject(CURL *obj)
{
	SEXP ans;
	if(!obj) {
		PROBLEM "NULL CURL handle being returned"
		ERROR;
	}

	PROTECT(ans = R_MakeExternalPtr((void *) obj, Rf_install("CURLHandle"), R_NilValue));
	SET_CLASS(ans, mkString("CURLHandle"));
	R_RegisterCFinalizer(ans, R_finalizeCurlHandle);
	UNPROTECT(1);
	return(ans);
} 


#if 0
SEXP
R_getCURLOptionEnum()
{
 
	SEXP ans;
	int i = 0;
	ans = allocVector(INTSXP, 31);
	INTEGER(ans)[i++] = CURLOPT_FILE;
	INTEGER(ans)[i++] = CURLOPT_URL;
	INTEGER(ans)[i++] = CURLOPT_PORT;
	INTEGER(ans)[i++] = CURLOPT_PROXY;
	INTEGER(ans)[i++] = CURLOPT_USERPWD;
	INTEGER(ans)[i++] = CURLOPT_PROXYUSERPWD;
	INTEGER(ans)[i++] = CURLOPT_RANGE;
	INTEGER(ans)[i++] = CURLOPT_INFILE;
	INTEGER(ans)[i++] = CURLOPT_ERRORBUFFER;
	INTEGER(ans)[i++] = CURLOPT_WRITEFUNCTION;
	INTEGER(ans)[i++] = CURLOPT_READFUNCTION;
	INTEGER(ans)[i++] = CURLOPT_TIMEOUT;
	INTEGER(ans)[i++] = CURLOPT_INFILESIZE;
	INTEGER(ans)[i++] = CURLOPT_POSTFIELDS;
	INTEGER(ans)[i++] = CURLOPT_REFERER;
	INTEGER(ans)[i++] = CURLOPT_FTPPORT;
	INTEGER(ans)[i++] = CURLOPT_USERAGENT;
	INTEGER(ans)[i++] = CURLOPT_LOW_SPEED_LIMIT;
	INTEGER(ans)[i++] = CURLOPT_LOW_SPEED_TIME;
	INTEGER(ans)[i++] = CURLOPT_RESUME_FROM;
	INTEGER(ans)[i++] = CURLOPT_COOKIE;
	INTEGER(ans)[i++] = CURLOPT_COOKIE;
	INTEGER(ans)[i++] = CURLOPT_HTTPHEADER;
	INTEGER(ans)[i++] = CURLOPT_HTTPPOST;
	INTEGER(ans)[i++] = CURLOPT_SSLCERT;
		     
	INTEGER(ans)[i++] = CURLOPT_VERBOSE;
	INTEGER(ans)[i++] = CURLOPT_FOLLOWLOCATION;
		     
	INTEGER(ans)[i++] = CURLOPT_NETRC;
	INTEGER(ans)[i++] = CURLOPT_HTTPAUTH;
	INTEGER(ans)[i++] = CURLOPT_COOKIEFILE;

	INTEGER(ans)[i++] = CURLOPT_PASSWDFUNCTION;

	return(ans);
}
#endif

static const char *const VersionInfoFieldNames[] = 
  {"age", "version", "vesion_num", "host", "features", "ssl_version",
   "ssl_version_num", "libz_version", "protocols", "ares", "ares_num","libidn"
  };

SEXP
RCurlVersionInfoToR(curl_version_info_data *d)
{
   SEXP ans, tmp;
   int n;
   n = sizeof(VersionInfoFieldNames)/sizeof(VersionInfoFieldNames[0]);

   PROTECT(ans = allocVector(VECSXP, n));
   SET_VECTOR_ELT(ans, 0, ScalarInteger(d->age));
   SET_VECTOR_ELT(ans, 1, mkString(d->version));
   SET_VECTOR_ELT(ans, 2, ScalarInteger(d->version_num));
   SET_VECTOR_ELT(ans, 3, mkString(d->host));
   SET_VECTOR_ELT(ans, 4, ScalarInteger(d->features)); 
   SET_VECTOR_ELT(ans, 5, mkString(d->ssl_version ? d->ssl_version : ""));
   SET_VECTOR_ELT(ans, 6, ScalarInteger(d->ssl_version_num));
   SET_VECTOR_ELT(ans, 7, mkString(d->libz_version));

   SET_VECTOR_ELT(ans, 8, getRStringsFromNullArray(d->protocols));

   SET_VECTOR_ELT(ans, 9, mkString(d->ares ? d->ares : ""));
   SET_VECTOR_ELT(ans, 10, ScalarInteger(d->ares_num));



#ifdef HAVE_LIBIDN_FIELD
   PROTECT(tmp = mkString(d->libidn ? d->libidn : ""));
#else
   PROTECT(tmp = allocVector(STRSXP, 1));
   SET_STRING_ELT(tmp, 0, R_NaString);
#endif

   SET_VECTOR_ELT(ans, 11, tmp);
   UNPROTECT(1);


   SET_NAMES(ans, RCreateNamesVec(VersionInfoFieldNames, n));

   UNPROTECT(1);
   return(ans);
}

SEXP
RCreateNamesVec(const char * const *vals,  int n)
{
	SEXP ans;
	int i;

	PROTECT(ans = allocVector(STRSXP, n));
	for(i = 0; i < n ; i++) {
	    SET_STRING_ELT(ans, i, mkChar(vals[i]));
	}

	UNPROTECT(1);
	return(ans);
}

SEXP
getRStringsFromNullArray(const char **d)  
{
  int i, n;
  const char **p;
  SEXP ans;

  for(p = d, n = 0; *p; p++, n++) ;

  PROTECT(ans = allocVector(STRSXP, n));
  for(p = d, i = 0; i < n; i++, p++) {
	  SET_STRING_ELT(ans, i, mkChar(*p));
  }

  UNPROTECT(1);
  return(ans);
}






#if 0
char *DefaultURL = "http://www.omegahat.org/index.html";
void
R_test_curl(void)
{
	CURL *h;
	char **url = &DefaultURL;
	CURLcode status;


	h = curl_easy_init();
	status = curl_easy_setopt(h, CURLOPT_URL, NULL);
	if(status) {
		fprintf(stderr, "Expected error %d", status);fflush(stderr);
	}
	curl_easy_setopt(h, CURLOPT_URL, *url);
	curl_easy_perform(h);
}
#endif




void
R_check_bits(int *val, int *bits, int *ans, int *n)
{
	int i;
	for(i = 0; i < *n; i++) {
		ans[i] = *val & bits[i];
	}
}


